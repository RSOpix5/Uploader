package si.fri.rso.samples.customers.api.v1.dtos;

public class LoadDto {

    private Integer n;

    public Integer getN() {
        return n;
    }

    public void setN(Integer n) {
        this.n = n;
    }
}
