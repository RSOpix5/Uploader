package si.fri.rso.samples.customers.api.v1.dtos;

public class HealthDto {

    private Boolean healthy;

    public Boolean getHealthy() {
        return healthy;
    }

    public void setHealthy(Boolean healthy) {
        this.healthy = healthy;
    }
}
